<?php
declare(strict_types=1);
require_once __DIR__ . "/vendor/autoload.php";

use MVQN\UCRM\Plugins\Plugin;
use MVQN\UCRM\Plugins\Settings;

use MVQN\REST\RestClient;

// Regenerate the Settings class, in case anything has changed in the manifest.json file.
Plugin::initialize(__DIR__);
Plugin::createSettings();

// Configure the REST Client...
RestClient::setBaseUrl(Settings::UCRM_PUBLIC_URL . "api/v1.0");
RestClient::setHeaders([
    "Content-Type: application/json",
    "X-Auth-App-Key: " . Settings::PLUGIN_APP_KEY
]);

// Configure the Twig template environment.
$loader = new Twig_Loader_Filesystem(__DIR__ . "/twig/");
$twig = new Twig_Environment($loader, [
    //"cache" => __DIR__."/twig/.cache/"
]);
