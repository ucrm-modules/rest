<?php
declare(strict_types=1);
require_once __DIR__ . "/vendor/autoload.php";

use MVQN\UCRM\Plugins\Log;
use MVQN\UCRM\Plugins\Settings;

use MVQN\Common\HTML;

use MVQN\REST\UCRM\Endpoints\WebhookEvent;
use MVQN\REST\UCRM\Endpoints\Client;
use MVQN\REST\UCRM\Endpoints\ClientContact;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

/**
 * public.php
 *
 * Handles webhook delivery of entity changes.
 * @author Ryan Spaeth <rspaeth@mvqn.net>
 */
(function()
{
    // Include the bootstrap.php configuration and setup file.
    require_once __DIR__."/bootstrap.php";

    // Configure the language...
    $translations = include_once __DIR__."/translations/" . (Settings::getLanguage() ?: "en_US") . ".php";

    // Parse the input received from Webhook events.
    $data = file_get_contents("php://input");
    Log::write("RECEIVED: ".$data);

    // Parse the JSON payload into an array for further handling.
    $dataArray = json_decode($data, true);

    // IF the array/payload is empty...
    if (!$dataArray) {
        // THEN return a "Bad Request" response and skip this event!
        http_response_code(400);
        Log::write("SKIPPING: The Webhook Event payload was empty!\n".$data);
        die("The Webhook Event payload was empty!\n".$data);
    }

    // Attempt to get the UUID from the payload.
    $uuid = array_key_exists("uuid", $dataArray) ? $dataArray["uuid"] : "";

    // IF the data does not include a valid UUID...
    if (!$uuid)
    {
        // THEN return a "Bad Request" response and skip this event!
        http_response_code(400);
        Log::write("SKIPPING: The Webhook Event payload did not contain a valid UUID field!\n$data");
        die("The Webhook Event payload did not contain a valid UUID field!\n$data");
    }

    // OTHERWISE, attempt to get the Webhook Event from the UCRM system for validation...
    $event = WebhookEvent::getByUuid($uuid);

    // IF the Webhook Event exists in the UCRM...
    if ($event->getUuid() === $uuid)
    {
        // THEN we should be good to continue!

        // Get the individual values from the payload.
        $changeType = $dataArray["changeType"]; // edit
        $entityType = $dataArray["entity"]; // client
        $entityId = $dataArray["entityId"]; // 1
        $eventName = $dataArray["eventName"]; // client.edit

        // Setup some empty containers to handle the payload.
        $html = "";
        $text = "";
        $recipients = [];
        $subject = "";

        // Handle the different Webhook Event types...
        switch ($entityType) {
            case "client":
                /** @var Client $client Get the actual Client from the UCRM. */
                $client = Client::getById($entityId);

                // IF the Webhook Event is for a Client, but the "Client Leads Only" checkbox is not checked...
                if (!$client->getIsLead() && Settings::getClientLeadsOnly()) {
                    // THEN log and skip this Webhook Event!
                    Log::write("SKIPPING: The Webhook Event targeted a Client and 'Client Leads Only?' was enabled!");
                    die("The Webhook Event targeted a Client and 'Client Leads Only?' was enabled!");
                }

                /** @var ClientContact[] $contacts Get the actual Client Contacts from the UCRM. */
                $contacts = $client->getContacts()->elements();

                // Build some view data to be passed to the Twig template.
                $viewData =
                    [
                        "translations" => $translations,
                        "client" => $client,
                        "contacts" => $contacts,
                        "url" => Settings::UCRM_PUBLIC_URL,
                        "googleMapsApiKey" => getenv("GOOGLE_MAPS_API_KEY") ?: "",
                    ];

                // Generate the HTML version of the email, then minify and reformat cleanly!
                $html = HTML::tidyHTML(HTML::minify($twig->render("client/add.html.twig", $viewData)));

                // Generate the TEXT version of the email, to be used as a fall back!
                $text = $twig->render("client/add.text.twig", $viewData);

                // Set the appropriate set of recipients for this notification.
                $recipients = explode(",", Settings::getClientRecipients());

                // Set the appropriate subject line for this notification.
                $subject = $client->getIsLead() ? $translations["CLIENT_LEAD_ADDED"] : $translations["CLIENT_ADDED"];

                // Should be ready to send...
                break;

            // TODO: Add the other event types as needed!!!

            default:
                http_response_code(200);
                Log::write("SKIPPING: The Webhook Event Type: '$entityType' is not currently supported!");
                die("The Webhook Event Type: '$entityType' is not currently supported!");
        }

        // Initialize an instance of the mailer!
        $mail = new PHPMailer(true);

        // Setup the mailer for our use here...
        try {
            //$mail->SMTPDebug = 2;
            $mail->isSMTP();
            $mail->Host = Settings::getSmtpServer();
            $mail->SMTPAuth = true;
            $mail->Username = Settings::getSmtpUsername();
            $mail->Password = Settings::getSmtpPassword();
            if (Settings::getSmtpEncryption() !== "")
                $mail->SMTPSecure = Settings::getSmtpEncryption();
            $mail->Port = Settings::getSmtpPort();
            $mail->setFrom(Settings::getSmtpSenderEmail(), Settings::getSmtpSenderName());

            foreach ($recipients as $email)
                $mail->addAddress($email);

            $mail->addReplyTo(Settings::getSmtpSenderEmail(), Settings::getSmtpSenderName());

            //Attachments
            //$mail->addAttachment('/var/tmp/file.tar.gz');
            //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');

            $mail->isHTML(Settings::getSmtpUseHTML());
            $mail->Subject = $subject;
            $mail->Body = $html;
            $mail->AltBody = $text;

            // Finally, attempt to send the message!
            $mail->send();

            // IF we've made it this far, the message should have sent successfully, notify the system.
            http_response_code(200);
            Log::write("SUCCESS : A valid Webhook Event was received and a notification message sent successfully!");
            die("A valid Webhook Event was received and a notification message sent successfully!");
        }
        catch (Exception $e)
        {
            // OTHERWISE, something went wrong, so notify the system of failure.
            http_response_code(400);
            Log::write("ERROR   : Message could not be sent, Mailer Error: '{$mail->ErrorInfo}'");
            die("Message could not be sent, Mailer Error: '{$mail->ErrorInfo}'");
        }
    }

    // SHOULD NEVER REACH HERE!

})();
