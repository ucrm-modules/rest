<?php
declare(strict_types=1);

namespace MVQN\UCRM\Plugins;

/**
 * @author Ryan Spaeth <rspaeth@mvqn.net>
 *
 * @method static bool|null getDebugEnabled()
 * @method static string|null getLanguage()
 * @method static string getSmtpServer()
 * @method static string getSmtpUsername()
 * @method static string getSmtpPassword()
 * @method static string|null getSmtpEncryption()
 * @method static string getSmtpPort()
 * @method static string getSmtpSenderName()
 * @method static string getSmtpSenderEmail()
 * @method static bool|null getSmtpUseHTML()
 * @method static bool|null getClientLeadsOnly()
 * @method static string getClientRecipients()
 */
final class Settings extends SettingsBase
{
	/** @const string The absolute path to the root path of this project. */
	public const PLUGIN_ROOT_PATH = 'C:\Users\rspaeth\Documents\PhpStorm\Projects\mvqn\ucrm\plugin-notifier\zip';

	/** @const string The absolute path to the data path of this project. */
	public const PLUGIN_DATA_PATH = 'C:\Users\rspaeth\Documents\PhpStorm\Projects\mvqn\ucrm\plugin-notifier\zip\data';

	/** @const string The absolute path to the source path of this project. */
	public const PLUGIN_SOURCE_PATH = 'C:\Users\rspaeth\Documents\PhpStorm\Projects\mvqn\ucrm\plugin-notifier\zip\src';

	/** @const string The publicly accessible URL of this UCRM, null if not configured in UCRM. */
	public const UCRM_PUBLIC_URL = 'http://ucrm.dev.mvqn.net/';

	/** @const string An automatically generated UCRM API 'App Key' with read/write access. */
	public const PLUGIN_APP_KEY = '9jcxnqiE8rVhKzrxNviFCPrF8jkRhkEznuruePniYy01oYYR3z/5m3n6SSAYYW/v';

	/**
	 * Debug Enabled?
	 * @var bool|null If enabled, verbose debug messages are sent to the log.
	 */
	protected static $debugEnabled;

	/**
	 * Language
	 * @var string|null The desired language for notifications.
	 */
	protected static $language;

	/**
	 * SMTP Server
	 * @var string The SMTP server from which messages should be sent.
	 */
	protected static $smtpServer;

	/**
	 * SMTP Username
	 * @var string The SMTP username for which to use during the authentication process.
	 */
	protected static $smtpUsername;

	/**
	 * SMTP Password
	 * @var string The SMTP password for which to use during the authentication process.
	 */
	protected static $smtpPassword;

	/**
	 * SMTP Encryption
	 * @var string|null The SMTP encryption type to use during the authentication process.
	 */
	protected static $smtpEncryption;

	/**
	 * SMTP Port
	 * @var string The SMTP port to which messages should be sent (i.e. None: 25, TLS: 587, SSL: 465, etc.).
	 */
	protected static $smtpPort;

	/**
	 * Sender Name
	 * @var string The name of the sender (will also be used as the 'Reply To' name).
	 */
	protected static $smtpSenderName;

	/**
	 * Sender Email
	 * @var string The email of the sender (will also be used as the 'Reply To' email).
	 */
	protected static $smtpSenderEmail;

	/**
	 * Use HTML?
	 * @var bool|null If enabled, will attempt to send messages in HTML format.
	 */
	protected static $smtpUseHTML;

	/**
	 * Client Leads Only?
	 * @var bool|null If enabled, will only respond to Client events that belong to a Lead.
	 */
	protected static $clientLeadsOnly;

	/**
	 * Client Recipients
	 * @var string A comma separated list of email addresses to which Client notifications should be sent.
	 */
	protected static $clientRecipients;
}
