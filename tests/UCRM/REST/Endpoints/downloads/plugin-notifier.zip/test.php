<?php
declare(strict_types=1);
require __DIR__ . "/vendor/autoload.php";

use MVQN\UCRM\Plugins\Plugin;
use MVQN\UCRM\Plugins\Settings;
use MVQN\REST\RestClient;

Plugin::initialize(__DIR__);
Plugin::createSettings();


echo Settings::UCRM_PUBLIC_URL."\n";
echo Settings::PLUGIN_APP_KEY."\n";

// Configure the REST Client...
RestClient::setBaseUrl(Settings::UCRM_PUBLIC_URL."api/v1.0");
RestClient::setHeaders([
    "Content-Type: application/json",
    "X-Auth-App-Key: ".Settings::PLUGIN_APP_KEY
]);

//var_dump(RestClient::get("/countries"));

//file_put_contents(__DIR__."/testing.txt", "Test");

//var_dump(Plugin::fixPermissions());


Plugin::bundle(__DIR__, "plugin-notifier", __DIR__."/.zipignore", __DIR__."/../");