<?php
/**
 * Localization file template in English (United States).
 *
 * @author Ryan Spaeth <rspaeth@mvqn.net>
 */

$translations = [];

// This will be the used in the '<html lang=X>'
// field and may not necessarily coincide with the
// language file name.
$translations["HTML_LANG"]                          = "en";

// These will populate the head's <title> tag.
// And also be used for the email's Subject line.
$translations["CLIENT_ADDED"]                       = "New Client";
$translations["CLIENT_LEAD_ADDED"]                  = "New Client Lead";

// A single introductory line wrapped in a <p> tag.
$translations["CLIENT_SALUTATION"]                  = "Dear Sales Team,";

// Both of these can contain as many lines of text
// as desired and each string will be wrapped in
// it's own <p> tag.
$translations["CLIENT_CONTENT"]                     = [ "The following Client has been added to your UCRM." ];
$translations["CLIENT_LEAD_CONTENT"]                = [ "The following Client Lead has been added to your UCRM." ];

// Represents the possible Client types, per UCRM.
$translations["CLIENT_TYPE_COMMERCIAL"]             = "Commercial";
$translations["CLIENT_TYPE_RESIDENTIAL"]            = "Residential";

// Used for link building, so if your UCRM links use
// english words, do not change these!
// Currently, these also coincide with the Webhook
// event entities, but this may not always be true.
$translations["CLIENT"]                             = "client";
$translations["INVOICE"]                            = "invoice";
$translations["PAYMENT"]                            = "payment";
$translations["QUOTE"]                              = "quote";
$translations["SERVICE"]                            = "service";
$translations["TICKET"]                             = "ticket";
$translations["USER"]                               = "user";

// Used for the content section headers.
$translations["CLIENT_TITLE"]                       = "Client";
$translations["CLIENT_CONTACTS_TITLE"]              = "Contacts";

// Used for the labeling of fields.
$translations["CLIENT_TYPE"]                        = "Client Type   ";
$translations["CLIENT_NAME"]                        = "Client Name   ";
$translations["CLIENT_ADDRESS"]                     = "Client Address";
$translations["CLIENT_LINK"]                        = "Client Link   ";
$translations["CLIENT_CONTACT_NAME"]                = "Contact Name  ";
$translations["CLIENT_CONTACT_PHONE"]               = "Contact Phone ";
$translations["CLIENT_CONTACT_EMAIL"]               = "Contact Email ";

// Used for empty text values.
$translations["EMPTY_TEXT"]                         = "None Provided";

// TODO: Add other localization values as needed...

// Return the collection of translations!
return $translations;

