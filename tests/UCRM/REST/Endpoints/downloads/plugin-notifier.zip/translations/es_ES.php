<?php
/**
 * Localization file template in Spanish (Spain/Traditional).
 *
 * NOTE: Performed by Google Translate, so it would be wise to have someone who speaks the language verify!
 *
 * @author Ryan Spaeth <rspaeth@mvqn.net>
 */

$translations = [];

// This will be the used in the '<html lang=X>'
// field and may not necessarily coincide with the
// language file name.
$translations["HTML_LANG"]                          = "es";

// These will populate the head's <title> tag.
$translations["CLIENT_ADDED"]                       = "Nuevo Cliente";
$translations["CLIENT_LEAD_ADDED"]                  = "Nuevo Cliente Potencial";

// A single introductory line wrapped in a <p> tag.
$translations["CLIENT_SALUTATION"]                  = "Estimado Equipo de Ventas,";

// Both of these can contain as many lines of text
// as desired and each string will be wrapped in
// it's own <p> tag.
$translations["CLIENT_CONTENT"]                     = [ "El siguiente Cliente se ha agregado a su UCRM." ];
$translations["CLIENT_LEAD_CONTENT"]                = [ "El siguiente Cliente Potencial se ha agregado a su UCRM." ];

// Represents the possible Client types, per UCRM.
$translations["CLIENT_TYPE_COMMERCIAL"]             = "Comercial";
$translations["CLIENT_TYPE_RESIDENTIAL"]            = "Residencial";

// Used for link building, so if your UCRM links
// use english words, do not change these!
// Currently, these also coincide with the Webhook
// event entities, but this may not always be true.
$translations["CLIENT"]                             = "client";
$translations["INVOICE"]                            = "invoice";
$translations["PAYMENT"]                            = "payment";
$translations["QUOTE"]                              = "quote";
$translations["SERVICE"]                            = "service";
$translations["TICKET"]                             = "ticket";
$translations["USER"]                               = "user";

// Used for the content section headers.
$translations["CLIENT_TITLE"]                       = "Cliente";
$translations["CLIENT_CONTACTS_TITLE"]              = "Contactos";

// Used for descriptions of values.
$translations["CLIENT_TYPE"]                        = "Tipo de Cliente      ";
$translations["CLIENT_NAME"]                        = "Nombre del Cliente   ";
$translations["CLIENT_ADDRESS"]                     = "Dirección del Cliente";
$translations["CLIENT_LINK"]                        = "URL del Cliente      ";
$translations["CLIENT_CONTACT_NAME"]                = "Nombre de Contacto   ";
$translations["CLIENT_CONTACT_PHONE"]               = "Teléfono de Contacto ";
$translations["CLIENT_CONTACT_EMAIL"]               = "Email de Contacto    ";

// Used for empty text values.
$translations["EMPTY_TEXT"]                         = "Ninguno Proporcionado";

// TODO: Add other localization values as needed...

// Return the collection of translations!
return $translations;

